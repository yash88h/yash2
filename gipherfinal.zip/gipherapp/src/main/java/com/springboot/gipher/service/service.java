package com.springboot.gipher.service;

import java.util.ArrayList;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.gipher.modal.gipher;
import com.springboot.gipher.repository.gipherrepo;





@Service
public class service implements serviceinter {
	
	@Autowired
	private gipherrepo gr;

	/*public void display(List<String> giffy)
	{
		for(int i=0;i<giffy.size();i++ )
		{
	ImageIcon gif1=new ImageIcon(giffy.get(i));
	JLabel gifLabel = new JLabel(gif1);

	JFrame frame = new JFrame();

	frame.getContentPane().add(gifLabel);

	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	frame.pack();
	frame.setVisible(true);
		}
	}*/
	@Override
	public List<String> addfav1(gipher g) {
		// TODO Auto-generated method stub
		
		
		if(gr.existsById(g.getimageid()))
		{
			//gipher g=gr.findById(imageid).get();
			//g.setFav(g.getAddfavv());
			gr.save(g);
			return g.getFav();
		}
		return null;
	}

	@Override
	public List<String> displayfav(int imageid) {
		// TODO Auto-generated method stub
		if(gr.existsById(imageid))
		{
			gipher g=gr.findById(imageid).get();
			//display(g.getFav());
			return g.getFav();
		}
		return null;
	}
	@Override
	public List<String> searchall(int imageid,List<String> c1, List<String> c2) {
		// TODO Auto-generated method stub
		if(gr.existsById(imageid))
		{
			//display(c1);
			//display(c2);
			List<String> ar=new ArrayList<>();
			for(int i=0;i<c1.size();i++)
			{
				ar.add(c1.get(i));
			}
			for(int i=0;i<c2.size();i++)
			{
				ar.add(c2.get(i));
			}
			return ar;
		}
		
		return null;
	}
	@Override
	public List<String> searchcategory( int imageid,List<String> c) {
		// TODO Auto-generated method stub
		if(gr.existsById(imageid))
		{
			
			//display(c);
			return c;
		}
		return null;
	}
	@Override
	public List<String> searchbyid(int imageid) {
		// TODO Auto-generated method stub
		if(gr.existsById(imageid))
		{
			//display(gr.findById(imageid).get().getFirst());
			//display(gr.findById(imageid).get().getSecond());
			List<String> ar=new ArrayList<>();
			for(int i=0;i<gr.findById(imageid).get().getFirst().size();i++)
			{
				ar.add(gr.findById(imageid).get().getFirst().get(i));
			}
			for(int i=0;i<gr.findById(imageid).get().getSecond().size();i++)
			{
				ar.add(gr.findById(imageid).get().getSecond().get(i));
			}
			return ar;
		}
		return null;
	}
	@Override
	public List<String> recommendall(int imageid) {
		// TODO Auto-generated method stub
		if(gr.existsById(imageid))
		{
			List<String> ar=new ArrayList<>();
			for(int i=0;i<gr.findById(imageid).get().getFirst().size();i++)
			{
				ar.add(gr.findById(imageid).get().getFirst().get(i));
			}
			for(int i=0;i<gr.findById(imageid).get().getSecond().size();i++)
			{
				ar.add(gr.findById(imageid).get().getSecond().get(i));
			}
			return ar;
			
		}
		return null;
	}
	@Override
	public String recommendagif(int imageid) {
		// TODO Auto-generated method stub
		if(gr.existsById(imageid))
		{
			return gr.findById(imageid).get().getSecond().get(0);
		}
		return null;
	}
	@Override
	public gipher update(gipher g) {
		// TODO Auto-generated method stub
		if(gr.existsById(g.getimageid()))
		{
			gr.save(g);
			return g;
		}
		return null;
	}
	@Override
	public gipher deleteuser(int imageid) {
		// TODO Auto-generated method stub
		/*if(gr.existsById(imageid))
		{
			gipher g=gr.findById(imageid).get();
			gr.deleteById(imageid);
			return g;
		}
		return null;*/
		 
	    
	    // Check if a gipher with the given imageid exists
	    if ( gr.existsById(imageid)) {
	        gipher gipher = gr.findById(imageid).get();
	        
	        try {
	            // Delete the gipher object from the repository
	            gr.deleteById(imageid);
	            return gipher;
	        } catch (Exception e) {
	            // Handle any exceptions that occur during deletion
	            e.printStackTrace(); // Log the exception for debugging
	            throw new RuntimeException("Failed to delete gipher");
	        }
	    } else {
	        // Return null or handle the case where the gipher doesn't exist
	        return null;
	    }
		
	}
	@Override
	public gipher addUser(gipher g) {
		// TODO Auto-generated method stub
		if(gr.existsById(g.getimageid()))
		 {
		 return null;
		 }
		 gr.save(g);
		 return g;
	}
	@Override
	public gipher getuserbyid(int imageid) {
		// TODO Auto-generated method stub
		if(gr.existsById(imageid))
		{
			return gr.findById(imageid).get();
		}
		return null;
	}
	
	

}
