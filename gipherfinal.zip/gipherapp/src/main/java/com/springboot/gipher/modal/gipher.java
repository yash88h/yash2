package com.springboot.gipher.modal;

import java.util.List;

import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.swing.*;

@Entity
public class gipher {

	@Id
	@Column(length = 20)
	private int imageid;
	@Column(length = 100)
	private String username;
	@ElementCollection
	@CollectionTable(name = "fav_values", joinColumns = @JoinColumn(name = "imageid"))
    @Column(length=100,name = "fav")
	List<String> fav;
	//@Column(length = 50)
	//List<String> addfavv;
	@Column(length = 50)
	String cat1;
	@ElementCollection
	@CollectionTable(name = "first_values", joinColumns = @JoinColumn(name = "imageid"))
    @Column(length=100,name = "first")
	List<String> first;
	@Column(length = 50)
	String cat2;
	@ElementCollection
	@CollectionTable(name = "second_values", joinColumns = @JoinColumn(name = "imageid"))
    @Column(length=100,name = "second")
	List<String> second;
	@Column(length = 50)
	String searchcat;
	
     @Lob
    @Column(length=500,name = "image", columnDefinition = "BLOB")
    private String image;
     public gipher() {
         // Initialize any default values or leave it empty
    	 super();
     }


	public gipher(int imageid, String username, List<String> fav, String cat1,List<String> f,String cat2,List<String> s,String sc,String image) {
		super();
		this.imageid = imageid;
		this.username = username;
		this.fav = fav;
		this.image = image;
		this.cat1=cat1;
		this.cat2=cat2;
		this.first=f;
		this.second=s;
		//this.addfavv=addfavv;
		this.searchcat=sc;
		
	}
	
	/*public List<String> getAddfavv() {
		return addfavv;
	}

	public void setAddfavv(List<String> addfavv) {
		this.addfavv = addfavv;
	}*/

	public String getCat1() {
		return cat1;
	}

	public void setCat1(String cat1) {
		this.cat1 = cat1;
	}

	public List<String> getFirst() {
		return first;
	}

	public void setFirst(List<String> first) {
		this.first = first;
	}

	public String getCat2() {
		return cat2;
	}

	public void setCat2(String cat2) {
		this.cat2 = cat2;
	}

	public List<String> getSecond() {
		return second;
	}

	public void setSecond(List<String> second) {
		this.second = second;
	}

	public String getSearchcat() {
		return searchcat;
	}

	public void setSearchcat(String searchcat) {
		this.searchcat = searchcat;
	}

	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	
	
	public int getimageid() {
		return imageid;
	}
	public void setimageid(int imageid) {
		this.imageid = imageid;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public List<String> getFav() {
		return fav;
	}
	public void setFav(List<String> fav) {
		this.fav = fav;
	}
	@Override
	public String toString() {
		return "gipherapp [userid=" + imageid + ", username=" + username + ", image=" + image + ", return=" + fav+ "]";
	}
	
}
