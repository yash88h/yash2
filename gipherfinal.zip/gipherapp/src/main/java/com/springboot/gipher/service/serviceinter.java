package com.springboot.gipher.service;

import java.util.List;

import javax.swing.ImageIcon;

import com.springboot.gipher.modal.gipher;



public interface serviceinter {

	public gipher addUser(gipher g);
	public gipher getuserbyid(int imageid);
	public  List<String> addfav1(gipher g);
	public List<String> displayfav(int imageid);
	public  List<String> searchall(int imageid,List<String> c1,List<String> c2);
	public List<String> searchcategory(int imageid,List<String> c);
	public List<String> searchbyid(int imageid);
	public List<String> recommendall(int imageid);
	public String recommendagif(int imageid);//spuend any element of "first" or "second" array
	public gipher update(gipher g);
	public gipher deleteuser(int imageid);
	
			
}
