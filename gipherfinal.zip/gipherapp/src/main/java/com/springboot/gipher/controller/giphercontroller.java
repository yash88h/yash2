package com.springboot.gipher.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.gipher.modal.gipher;
import com.springboot.gipher.service.service;


@RestController
@RequestMapping("/api/v1/gipher")
public class giphercontroller {
	
	@Autowired
	private service ps;
	
	@GetMapping("/{imageid}")
	public ResponseEntity<?> getuserbyid1(@PathVariable int imageid)
	{
		gipher g=ps.getuserbyid(imageid);
		if(g==null)
		{
			 return new ResponseEntity<String>("user does not exist",HttpStatus.CONFLICT);
		}
		return new ResponseEntity<gipher>(g,HttpStatus.CREATED);
	}
	
	@PostMapping(path="/adduser",consumes="application/json")
	 public ResponseEntity<?> addregistration(@RequestBody gipher g)
	{
	 gipher g1=ps.addUser(g);
	 if (g1==null)
	 {
	 return new ResponseEntity<String>("user already exist",HttpStatus.CONFLICT);
	 }
	 return new ResponseEntity<gipher>(g1,HttpStatus.CREATED);
	}
	
	
	@PutMapping("/addfeatures")
	public ResponseEntity<?> addfeature(@RequestBody gipher g)
	{
		List<String> ag=ps.addfav1(g);
		if(ag==null)
		{
			return new ResponseEntity<String>("user does not exist",HttpStatus.CONFLICT);	
		}
		return new ResponseEntity<List<String>>(ag,HttpStatus.CREATED);
	}
	@GetMapping("/displayfavv/{imageid}")
	public ResponseEntity<?> displayfav(@PathVariable int imageid)
	{
		List<String> give=ps.displayfav(imageid);
		if(give==null)
		{
			return new ResponseEntity<String>("user does not exist",HttpStatus.CONFLICT);
		}
		return new ResponseEntity<List<String>>(give,HttpStatus.CREATED);
	}
	@PutMapping("/update")
    public ResponseEntity<?> updateGipher(@RequestBody gipher Gipher) {
        gipher updatedGipher =ps.update(Gipher);
        if (updatedGipher != null) {
            return new ResponseEntity<gipher>(updatedGipher, HttpStatus.OK);
        } else {
            return new ResponseEntity<String>("user not found",HttpStatus.NOT_FOUND);
        }
    }

    // Delete a gipher by imageid
    @DeleteMapping("/delete/{imageid}")
    public ResponseEntity<?> deleteGipher(@PathVariable int imageid) {
        gipher deletedGipher = ps.deleteuser(imageid);
        if (deletedGipher != null) {
            return new ResponseEntity<String>("user got deleted", HttpStatus.OK);
        } else {
            return new ResponseEntity<String>("user does not exist",HttpStatus.NOT_FOUND);
        }
        }
	@GetMapping("/recommendall/{imageid}")
    public ResponseEntity<?> recommendAll(@PathVariable int imageid) {
        List<String> recommendations =ps.recommendall(imageid);
        if (recommendations != null) {
            return new ResponseEntity<List<String>>(recommendations, HttpStatus.OK);
        } else {
            return new ResponseEntity<String>("user does not exist",HttpStatus.NOT_FOUND);
        }
    }
    @GetMapping("/recommendagif/{imageid}")
    public ResponseEntity<String> recommendAGif(@PathVariable int imageid) {
        String recommendation = ps.recommendagif(imageid);
        if (recommendation != null) {
            return new ResponseEntity<String>(recommendation, HttpStatus.OK);
        } else {
            return new ResponseEntity<String>("user not found",HttpStatus.NOT_FOUND);
        }
    }
	 @GetMapping("/category")
	    public ResponseEntity<?> searchCategory(@RequestBody gipher g) {
		 
		 List<String> r ;
	        if(g.getSearchcat().equals(g.getCat1()))
	        {
	        	r =ps.searchcategory(g.getimageid(), g.getFirst());
	        }
	        else 
	        	r=ps.searchcategory(g.getimageid(), g.getSecond());
	        
	       /* System.out.println(g.getSearchcat().length());
	        System.out.println(g.getSearchcat());
	        System.out.println(g.getCat1().length());
	        System.out.println(g.getCat1());*/

	        if (r == null) {
	        	return new ResponseEntity<String>("user does not exist",HttpStatus.CONFLICT);
	        }

	        return new ResponseEntity<List<String>>(r,HttpStatus.CREATED);
	    }

	    @GetMapping("/searchid/{imageid}")
	    public ResponseEntity<?> searchById(@PathVariable int imageid) {
	        List<String> result = ps.searchbyid(imageid);

	        if (result == null) {
	        	return new ResponseEntity<String>("user does not exist",HttpStatus.CONFLICT);
	        }

	        return new ResponseEntity<List<String>>(result,HttpStatus.CREATED);
	    }

	    @GetMapping("/all")
	    public ResponseEntity<?>searchAll(@RequestBody gipher g) {
	       List<String> searchResults = ps.searchall(g.getimageid(), g.getFirst(), g.getSecond());

	        if (searchResults==null) {
	        	return new ResponseEntity<String>("user does not exist",HttpStatus.CONFLICT);
	        }

	        return new ResponseEntity<List<String>>(searchResults,HttpStatus.CREATED);
	    }
	}


