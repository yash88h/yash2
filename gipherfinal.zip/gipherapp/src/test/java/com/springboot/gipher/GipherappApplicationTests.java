package com.springboot.gipher;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GipherappApplicationTests {

	@Test
	void contextLoads() {
	}

}
